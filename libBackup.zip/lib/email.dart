import 'package:flutter/material.dart';
//import 'firebase_access.dart';

class EmailVerifier extends StatefulWidget {
  const EmailVerifier({super.key});

  @override
  EmailVerifierState createState() => EmailVerifierState();
}

class EmailVerifierState extends State<EmailVerifier> {

  @override
  Widget build(BuildContext context) {
    return SizedBox();
  }
}