import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';


import 'package:cloud_firestore/cloud_firestore.dart';

import '../firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AuthScreen(),
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  AuthScreenState createState() => AuthScreenState();
}

class AuthScreenState extends State<AuthScreen> {
  // --------- Initialising Auth --------- //
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  int stateForcer = 0;
  User? _user;

  // --------- Document Settings --------- //
  final Color widgetMainColor = Color.fromARGB(255, 209, 196, 246);
  final ButtonStyle mainButtonStyling = ElevatedButton.styleFrom(
    minimumSize: Size(double.infinity, 50),
    backgroundColor: const Color.fromARGB(255, 233, 226, 253),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(5)
    ),
  );
  final EdgeInsets defaultContainerPadding = EdgeInsets.only(
    top: 20,
    left: 20, 
    right: 20,
    bottom: 0, 
  );

  // --------- Page Element Controllers --------- //
  final TextEditingController _numberController = TextEditingController();

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _usernameController = TextEditingController();

  String displayPage = ""; // Snake case pls
  String _logWarning = '';
  String displayName = 'Loading...';

  // --------- Variables --------- //
  int? _number = 0;

  // ================== TAB SWITCHING ================== //

  void setToRegisterPage() {
    setState(() {
      displayPage = 'register_page';
    });
  }

  void setToSignInPage() {
    setState(() {
      displayPage = 'sign_in_page';
    });
  }

  // ================== Database Operations ================== //

  Future<void> addUserCredToDatabase(userCredential) async {
    setState(() {
      _user = userCredential.user;
    });

    if (_user != null) {
      final userRef = _firestore.collection('users').doc(_user!.uid);
      final doc = await userRef.get();
      if (!doc.exists) {
        if (_user!.displayName == 'null' || _user!.displayName == null) {
          await userRef.set({'username': _usernameController.text.trim(), 'number': 0});
          setState(() {
            displayName = _usernameController.text.trim();
            stateForcer++;
          });
        } else {
          await userRef.set({'username': _user!.displayName, 'number': 0});
          setState(() {
            displayName = _user!.displayName.toString();
            stateForcer++;
          });
        }
      }
    }
  }

  Future<void> saveToDatabase(field, value) async {
    await _firestore.collection('users').doc(_user!.uid).update({field: value});
  }

  Future<void> saveNumber() async {
    if (_user == null || _numberController.text.isEmpty) return;

    int number = int.tryParse(_numberController.text) ?? 0;
    saveToDatabase('number', number);
  }

  Future<void> readNumber() async {
    DocumentSnapshot doc = await _firestore.collection('users').doc(_user!.uid).get();
    if (doc.exists) {
      int? number = (doc.data() as Map<String, dynamic>)['number'] as int?;
      setState(() {
        _number = number;
      });
    }
  }
  // Preferred Name
  Future<void> readName() async {
    DocumentSnapshot doc = await _firestore.collection('users').doc(_user!.uid).get();
    if (doc.exists) {
      String readDisplayName = (doc.data() as Map<String, dynamic>)['Preferred Name'] as String;
      setState(() {
        displayName = readDisplayName;
      });
    }
  }
  
  // ================== Sign-in Methods ================== //

  @override
  void initState() {
    super.initState();
    _user = _auth.currentUser;
  }

  Future<void> _signInWithEmail() async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      addUserCredToDatabase(userCredential);
    } catch (e) {
      setState(() {
        _logWarning = "Error Invalid Email or Password";
      });
      print("Error: $e");
    }
  }

  Future<void> _registerWithEmail() async {
    try {
      String email = _emailController.text.trim();
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: _passwordController.text.trim(),
      );
      setState(() {
        _user = userCredential.user;
      });

      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('email', isEqualTo: email)
        .get();

      DocumentSnapshot doc = querySnapshot.docs.first;
      String legacyUID = doc.id;

      if (querySnapshot.docs.isNotEmpty) { // WARNING NEED TO ACCOUNT FOR NON LEGACY SIMILAR EMAILS
        await _firestore.collection('users').doc(legacyUID).update({'Legacy UID': legacyUID});
        querySnapshot.toString();
        // Get the reference to the old document
        DocumentReference legacyDocRef = FirebaseFirestore.instance.collection('users').doc(legacyUID);

        // Get the data from the old document
        DocumentSnapshot legacyDocSnapshot = await legacyDocRef.get();

        Map<String, dynamic> data = legacyDocSnapshot.data() as Map<String, dynamic>;

        if (legacyDocSnapshot.exists) {
          // Create a new document with the new UID and copy the data
          await FirebaseFirestore.instance.collection('users').doc(_user!.uid).set(data);

          // Optionally, delete the old document if needed
          await legacyDocRef.delete();

          print("Document renamed successfully!");
        } else {
          print("No document found with the legacy UID.");
        }
      } else {
        addUserCredToDatabase(userCredential);
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> signInWithGoogle() async {
    final GoogleSignIn googleSignIn = GoogleSignIn(
      clientId: "371957954122-s6f25dm4382ira8adjero7voaa3f9ce8.apps.googleusercontent.com",
    );
    final GoogleSignInAccount? googleUser = await googleSignIn.signIn();
    if (googleUser == null) {
      return;
    }
    final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
    final AuthCredential credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    final UserCredential userCredential = await _auth.signInWithCredential(credential);
    addUserCredToDatabase(userCredential);
  }

  // ================== PAGES ================== //

  Widget generateSignInPage() {
    return Container(
      width: 300,
      height: 355,
      padding: defaultContainerPadding,
      color: widgetMainColor,
      child: Column(
        children: [
          Text("Sign In to Account",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.underline,
            ),
          ),
          SizedBox(height:10),
          TextField(controller: _emailController, decoration: InputDecoration(labelText: "Email")),
          TextField(controller: _passwordController, decoration: InputDecoration(labelText: "Password"), obscureText: true),
          SizedBox(
            height: 40,
            child: Text(_logWarning,
              style: TextStyle(
                color: Colors.pink,
              )
            ),
          ),
          ElevatedButton(
            onPressed: signInWithGoogle, 
            style: mainButtonStyling,
            child: Text("Sign In with Google"), 
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
            onPressed: _signInWithEmail, 
            style: mainButtonStyling,
            child: Text("Sign In!")
          ),
          SizedBox(height: 20),
          TextButton(
            onPressed: setToRegisterPage,
            style: TextButton.styleFrom(
              padding: EdgeInsets.only(
                top: 0,
                bottom: 0,
                left: 10,
                right: 10,
              ),
              minimumSize: Size(0, 0),  // Remove minimum button constraints
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5)
              ),
            ),
            child: Text('Register',
              style: TextStyle(
                color: const Color.fromARGB(255, 157, 76, 224),
                decoration: TextDecoration.underline,
              )
            ),
          ),
        ],
      )
    );
  }

  Widget generateRegisterPage() {
    return Container(
      width: 300,
      height: 400,
      padding: defaultContainerPadding,
      color: const Color.fromARGB(255, 209, 196, 246),
      child: Column(
        children: [
          Text("Create an Account",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.underline,
            ),
          ),
          SizedBox(height:10),
          TextField(controller: _emailController, decoration: InputDecoration(labelText: "Email")),
          TextField(controller: _passwordController, decoration: InputDecoration(labelText: "Password"), obscureText: true),
          TextField(controller: _usernameController, decoration: InputDecoration(labelText: "Preferred Name")),
          SizedBox(
            height: 40,
            child: Text(_logWarning,
              style: TextStyle(
                color: Colors.pink,
              )
            ),
          ),
          ElevatedButton(
            onPressed: signInWithGoogle, 
            style: mainButtonStyling,
            child: Text("Sign In with Google"), 
          ),
          SizedBox(
            height: 10,
          ),
          ElevatedButton(
            onPressed: _registerWithEmail, 
            style: mainButtonStyling,
            child: Text("Create New Account!")
          ),
          SizedBox(height: 20),
          TextButton(
            onPressed: setToSignInPage,
            style: TextButton.styleFrom(
              padding: EdgeInsets.only(
                top: 0,
                bottom: 0,
                left: 10,
                right: 10,
              ),
              minimumSize: Size(0, 0),  // Remove minimum button constraints
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5)
              ),
            ),
            child: Text('Sign in',
              style: TextStyle(
                color: const Color.fromARGB(255, 157, 76, 224),
                decoration: TextDecoration.underline,
              )
            ),
          ),
        ],
      )
    );
  }

  Widget generateDashboard() {
    readNumber();
    readName();
    return Container(
      width: 300,
      height: 400,
      padding: defaultContainerPadding,
      color: widgetMainColor,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text("Create an Account",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              decoration: TextDecoration.underline,
            ),
          ),
          Text('Welcome, ${_user!.displayName ?? displayName}!'),
          SizedBox(height: 10),
          TextField(
            controller: _numberController,
            decoration: InputDecoration(labelText: 'Credit CVV'),
            keyboardType: TextInputType.number,
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: saveNumber, 
            style: mainButtonStyling,
            child: Text('Save Credit CVV'), 
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: readNumber, 
            style: mainButtonStyling,
            child: Text("Update | Recorded CVV is ${_number.toString()}")
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              //await _auth.signOut(); // reset box
              //await _googleSignIn.signOut(); // Reset box
              setState(() {
                _user = null;
              });
            },
            style: mainButtonStyling,
            child: Text('Sign Out'),
          ),
        ],
      )
    );
  }

  // ================== MAIN ================== //

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Skeleton Firebase Test')),
      body: Center(
        child: _user == null
            ? displayPage == 'register_page' ? generateRegisterPage() : generateSignInPage()
            : generateDashboard()
              
      ),
    );
  }
}

