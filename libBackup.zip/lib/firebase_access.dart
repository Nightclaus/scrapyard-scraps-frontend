import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

final FirebaseAccess firebaseAccess = FirebaseAccess();

class FirebaseAccess {
  // --------- Initialising Auth --------- //
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  User? _user;
  String? selectedEmail;

  void setSelectedEmail(newEmail) {
    selectedEmail = newEmail;
  }

  String? getSelectedEmail() {
    return selectedEmail;
  }

  // ================== Database Operations ================== //

  Future<void> addUserCredToDatabase(userCredential) async {
    _user = userCredential.user;

    if (_user != null) {
      final userRef = _firestore.collection('users').doc(_user!.uid);
      final doc = await userRef.get();
      if (!doc.exists) {
        print("Error Account does not exisit");
      }
    }
  }

  Future<void> saveToDatabase(field, value) async {
    await _firestore.collection('users').doc(_user!.uid).update({field: value});
  }

  Future<void> saveNumber(int number) async {
    if (_user == null) return;
    saveToDatabase('number', number);
  }

  Future<int?> readNumber() async {
    DocumentSnapshot doc = await _firestore.collection('users').doc(_user!.uid).get();
    if (doc.exists) {
      int? number = (doc.data() as Map<String, dynamic>)['number'] as int?;
        return number;
    } else {
      return null;
    }
  }
  // Preferred Name
  Future<String?> readName() async {
    DocumentSnapshot doc = await _firestore.collection('users').doc(_user!.uid).get();
    if (doc.exists) {
      String readDisplayName = (doc.data() as Map<String, dynamic>)['Preferred Name'] as String;
      return readDisplayName;
    } else {
      return null;
    }
  }
  
  Future<String> readDate(userEmail) async {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('email', isEqualTo: userEmail)
        .get();

      DocumentSnapshot doc = querySnapshot.docs.first;
      //String uid = documentSnapshot.id;
      //DocumentSnapshot doc = await _firestore.collection('users').doc(uid).get();

      if (doc.exists) {
        String readDOB = (doc.data() as Map<String, dynamic>)['DOB'] as String;
        return readDOB;
      } else {
        return '';
      }
    }

    Future<String> getEmail(emailToVerify) async {
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: emailToVerify)
          .get();

      DocumentSnapshot documentSnapshot = querySnapshot.docs.first;
      String uid = documentSnapshot.id;
      DocumentSnapshot doc = await _firestore.collection('users').doc(uid).get();

      if (doc.exists) {
        String email = (doc.data() as Map<String, dynamic>)['email'] as String;
        return email;
      } else {
        return '';
      }
    }

  Future<List<List<String>>> getAllEntriesFromFirebase() async {
    QuerySnapshot querySnapshot = await _firestore
        .collection('users')
        .get();

    List<List<String>> allEntries = [];

    for (var doc in querySnapshot.docs) {
      Map<String, dynamic> user = doc.data() as Map<String, dynamic>;

      String gender = user['Pronouns'] ?? 'Unknown';
      String name = user['Full Name'] ?? 'Unknown';
      String email = user['email'] ?? 'Unknown';

      allEntries.add([gender, name, email]);
    }

    return allEntries;
  }

  Future<String> getScrapFromEmail(String email) async {
    try {
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
          .collection('users')
          .where('email', isEqualTo: email)
          .get();

      if (querySnapshot.docs.isEmpty) {
        return '0'; // Return default value if no matching document
      }

      // Retrieve the first document
      DocumentSnapshot doc = querySnapshot.docs.first;
      Map<String, dynamic> data = doc.data() as Map<String, dynamic>;

      if (data.containsKey('scraps') && data['scraps'] is int) {
        int scraps = data['scraps'] as int;
        print('Scraps: $scraps');
        return scraps.toString();
      } else {
        return '0'; // Return default if 'scraps' field is missing or incorrect
      }
    } catch (e) {
      print('Error: $e');
      return '0'; // Return default on error
    }
  }

  Future<void> addScrapToEmail(email, int amount) async {
    try {
      QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('users')
        .where('email', isEqualTo: email)
        .get();
      
      if (querySnapshot.docs.isEmpty) {
        return; // Return default value if no matching document
      }

      DocumentSnapshot doc = querySnapshot.docs.first;
      DocumentReference userRef = doc.reference;

      // Get current scraps value
      int currentScraps = (doc['scraps'] ?? 0) as int;

      // Update the scraps value by adding k
      await userRef.update({'scraps': currentScraps + amount});

    } catch (e) {
      print(e);
    }
  }
}