import 'package:supabase_flutter/supabase_flutter.dart';

final SupabaseAccess supabaseAccess = SupabaseAccess();

class SupabaseAccess {
  final SupabaseClient _supabase = Supabase.instance.client;
  String? selectedEmail;

  void setSelectedEmail(newEmail) {
    selectedEmail = newEmail;
  }

  String? getSelectedEmail() {
    return selectedEmail;
  }

  // Error Testing

  Future<bool> doesTableExist(String tableName) async {
  try {
    final _ = await _supabase.from(tableName).select().limit(10);
    return true;
  } catch (e) {
    print('Error: $e');
    return false;
  }
}

  void checkTable() async {
    bool exists = await doesTableExist('users');
    print(exists ? 'Table exists' : 'Table does not exist');
  }

  // ================== Database Operations ================== //

  Future<List<List<String>>> getAllEntriesFromDatabase() async {
    final response = await _supabase.from('users').select('Pronouns, full_name, email');

    List<List<String>> allEntries = [];

    for (var user in response) {
      String gender = user['Pronouns'] ?? 'Unknown';
      String name = user['full_name'] ?? 'Unknown';
      print(name);
      String email = user['email'] ?? 'Unknown';

      allEntries.add([gender, name, email]);
    }

    return allEntries;
  }

  Future<int?> _getIntVal(String email, String field) async {
    print('Fetch');
    try {
      final response = await _supabase
        .from('users')
        .select(field)
        .eq('email', email)
        .maybeSingle();

      if (response == null || response[field] == null) return null;
      return response[field] as int;
    } catch (e) {
      print('error in _getIntVal $e');
      return null;
    }
  }

  Future<String?> _getStringVal(String email, String field) async {
    print('Fetch');
    try {
      final response = await _supabase
        .from('users')
        .select(field)
        .eq('email', email)
        .maybeSingle();

      if (response == null || response[field] == null) return null;
      return response[field] as String;
    } catch (e) {
      print('error in _getIntVal $e');
      return null;
    }
  }

  Future<void> _updateVal(String email, String field, newValue) async {
    try {
      final _ = await _supabase
        .from('users')
        .update({field: newValue})
        .eq('email', email)
        .maybeSingle();
    } catch (e) {
      print(e);
    }
  }

  Future<String> getScrapFromEmail(String email) async {
    int numOfScraps = await _getIntVal(email, 'scraps') ?? 0;
    return numOfScraps.toString();
  }

  Future<void> addScrapToEmail(String email, int amount) async {
    int currentScraps = int.parse(await getScrapFromEmail(email));
    _updateVal(email, 'scraps', currentScraps+amount);
  }

  Future<bool> checkNfcTagValue(String email) async {
    String? response = await _getStringVal(email, 'nfc_tag');
    if (response == null || response=='null' || response=='') {
      return false;
    }
    return true;
  }

  Future<String> getNfcTagValue(String email) async {
    return await _getStringVal(email, 'nfc_tag') ?? 'Error';
  }

  Future<void> assignNfcTagValue(String email, String nfcValue) async {
    _updateVal(email, 'nfc_tag', nfcValue);
  }

  Future<String?> getFullNameFromNFC(String nfcTag) async {
    String field = 'full_name';
    try {
      final response = await _supabase
        .from('users')
        .select(field)
        .eq('nfc_tag', nfcTag)
        .maybeSingle();

      if (response == null || response[field] == null) return null;
      return response[field] as String;
    } catch (e) {
      print(e);
      return null;
    }
  }

  // ================== Decipricated ================== //

  Future<String> readDate(String userEmail) async {
    final response = await _supabase
        .from('users')
        .select('DOB')
        .eq('email', userEmail)
        .maybeSingle();

    return response?['DOB'] ?? '';
  }

  Future<String> getEmail(String emailToVerify) async {
    final response = await _supabase
        .from('users')
        .select('email')
        .eq('email', emailToVerify)
        .maybeSingle();

    return response?['email'] ?? '';
  }
}